
  export const postData= [
      {
        "id": 1,
        "title": "My First Post",
        "datetime": "July 01, 2021 11:17:36 AM",
        "body": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis consequatur expedita, assumenda similique non optio! Modi nesciunt excepturi corrupti atque blanditiis quo nobis, non optio quae possimus illum exercitationem ipsa!"
      },
      {
        "id": 2,
        "title": "My Second Post",
        "datetime": "March 31 , 2023 1:07:43 PM ",
        "body": "this is my second post"
      },
      {
        "id": 3,
        "title": "My 3rd Post",
        "datetime": "July 01, 2021 11:17:36 AM",
        "body": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis consequatur expedita, assumenda similique non optio! Modi nesciunt excepturi corrupti atque blanditiis quo nobis, non optio quae possimus illum exercitationem ipsa!"
      },
      {
        "id": 4,
        "title": "My Updated post",
        "datetime": "March 31 , 2023 2:08:59 PM ",
        "body": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quis consequatur expedita, assumenda similique non optio! Modi nesciunt excepturi corrupti atque blanditiis quo nobis, non optio quae possimus illum exercitationem ipsa!"
      }
    ]
  