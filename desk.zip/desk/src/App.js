import React from 'react';
// import logo from './logo.svg';
import './App.css';
import Minimum from './MINIMUM/MIN';
function App() {
return (
<div className="App">
<Minimum/>
</div>
);
}
export default App;
